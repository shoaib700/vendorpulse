# London Transfer Network

A deployable React + Tailwind app for booking minicabs, with Vercel-ready API routes for booking and fare calculation.

## Setup

1. Run `npm install`
2. Run `npm run dev` to start the app
3. Deploy to Vercel by linking your GitHub repo

## API

- `api/fare.js`: returns estimated fare
- `api/book.js`: simulates booking storage
